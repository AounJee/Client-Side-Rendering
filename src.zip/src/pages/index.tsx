import Image from "next/image";
import { Geist, Geist_Mono } from "next/font/google";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export default function Home() {
  return (
    <div className="snap-y snap-mandatory">
        <section className=" snap-start flex flex-col items-center justify-center min-h-screen p-4">
            <h1 className = "top-1/2 left-1/2 text-5xl">Hasnain Ali Arshad</h1>
        </section>

        <section className='snap-start'>
            <h2 className="text-3xl">About Me</h2>
            <p className="text-lg">
              I am a passionate software engineer with a focus on web development and
              design. I love creating beautiful and functional applications that solve
              real-world problems.
            </p>
            <div className="flex flex-col items-center">
             
            </div>
            <h2 className="text-3xl">Skills</h2>
            
        </section>
   </div>
  );
}
