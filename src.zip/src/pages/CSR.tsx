import useSWR from 'swr';
import React from 'react';

const fetcher = (url: string) => fetch(url).then(res => {
  if (!res.ok) throw new Error(`HTTP error: ${res.status}`);
  return res.json();
});

export default function CSR() {
  const { data, error, isLoading } = useSWR(
    'https://api.sampleapis.com/coffee/hot',
    fetcher
  );

  if (isLoading) return <p>Loading...</p>;
  if (error) return <p>Error: {error.message}</p>;

  return (
    <div>
      <h1>☕ Hot Coffee Menu (SWR)</h1>
      <ul>
        {data.map((item: any) => (
          <li key={item.id}>
            <strong>{item.title}</strong> — {item.description}
          </li>
        ))}
      </ul>
    </div>
  );
}
